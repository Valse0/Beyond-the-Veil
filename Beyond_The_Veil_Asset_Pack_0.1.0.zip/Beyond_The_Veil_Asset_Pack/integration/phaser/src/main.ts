import Phaser from 'phaser';
class VeilScene extends Phaser.Scene {
  constructor(){ super('veil'); }
  preload(){
    this.load.image('forest-bg','/assets/forest_bg.png');
    this.load.spritesheet('forest-tiles','/assets/forest_tiles.png',{frameWidth:32,frameHeight:32});
  }
  create(){
    const bg=this.add.image(0,0,'forest-bg').setOrigin(0).setDisplaySize(1280,720);
    bg.setDepth(-10);
    const map=this.make.tilemap({tileWidth:32,tileHeight:32,width:40,height:22});
    const tiles=map.addTilesetImage('forest-tiles',undefined,32,32,0,0);
    const layer=map.createBlankLayer('ground',tiles!);
    if(layer){ for(let y=0;y<22;y++) for(let x=0;x<40;x++) layer.putTileAt((x*7+y*3)%16,x,y); layer.setScale(1); }
    this.add.text(24,20,'BEYOND THE VEIL',{fontFamily:'monospace',fontSize:'20px',color:'#e8e0d2'}).setScrollFactor(0);
    this.cameras.main.setBounds(0,0,1280,720);
  }
}
new Phaser.Game({type:Phaser.AUTO,parent:'app',width:1280,height:720,backgroundColor:'#070a11',pixelArt:true,roundPixels:true,scale:{mode:Phaser.Scale.FIT,autoCenter:Phaser.Scale.CENTER_BOTH},scene:[VeilScene]});
