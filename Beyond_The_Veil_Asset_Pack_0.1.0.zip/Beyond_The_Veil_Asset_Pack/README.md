# BEYOND THE VEIL — Asset Pack 0.1.0

This is an original, editable production starter pack based on the two supplied visual references and the supplied Cursed Hunter archive.

## Art direction
Moonlit gothic dark fantasy; cold blue/slate shadows, weathered stone and iron, muted crimson foliage, restrained teal spirit light. The two supplied JPGs are preserved under `reference/`. The generated panorama is a forest/castle mood background, not a finished tileable level.

## Included
- `source_original/`: exact user-supplied ZIP plus extracted source files. Original 48x48, 8-direction Cursed Hunter idle sprites and original metadata are preserved without edits.
- `regions/`: five region folders, each with a 16-tile 32x32 terrain atlas and a 16-cell 64x64 modular prop sheet. Cursed Forest also has the generated moonlit panorama.
- `enemies/`: 25 named enemy concept silhouettes, five per region, 48x48 transparent PNGs.
- `bosses/`: five named 160x160 boss concept silhouettes.
- `weapons/`, `passives/`, `elements/`, `effects/`: original 32x32 icon prototypes.
- `integration/phaser/`: Vite + Phaser 3 TypeScript starter project showing pixel-art rendering and loading the Forest assets.
- `asset_manifest.json`: paths, dimensions, frame sizes, anchors, filtering, source and status metadata.

## Important production status
This is **asset pack 0.1.0 / visual prototype**, not the fully animated final asset library requested in the brief. To avoid misrepresenting it:
- Enemy and boss images are concept silhouettes with one frame each; they do not yet include 8-direction movement, attack, hurt, death, telegraphs or phase animations.
- The 5 region tilesets and prop atlases are prototype modular art, not yet a complete hand-authored seamless level kit. Only the Forest has a panoramic concept background.
- The other four playable hunters, full Cursed Hunter walk/attack/dash/hurt/death animations, all weapon attack/evolution sprites, and full UI screens are not included yet.
- The icon atlases are visual placeholders/prototypes and should be refined before shipping.
- Phaser scaffold is an integration starting point, not a finished game.

## Technical notes
- Pixel-art textures are authored at target sizes and intended for nearest-neighbor filtering.
- Character/enemy anchors use bottom-center; UI icons use center.
- Keep `pixelArt: true` and `roundPixels: true` in Phaser.
- Do not overwrite `source_original/` when generating future animation revisions.

## Build the Phaser starter
```bash
cd integration/phaser
npm install
npm run dev
```

## License / provenance
All procedural sprites and generated background art in this pack were created for this project in this session. User-supplied references and source archive are included solely as supplied project materials. No third-party sprite sheets were copied.
