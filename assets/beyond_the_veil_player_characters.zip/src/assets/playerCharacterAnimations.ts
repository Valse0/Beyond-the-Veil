import type Phaser from 'phaser';
import { getCharacterSpritesheetKey } from './playerCharacterAssets';
import {
  getPlayerManifest,
  type PlayerAnimationName,
  type PlayerCharacterMetadata,
  type PlayerDirection,
} from './playerCharacterManifest';

export function getPlayerAnimationKey(
  characterId: string,
  animationName: PlayerAnimationName,
  direction: PlayerDirection
): string {
  return `${characterId}:${animationName}:${direction}`;
}

export function registerPlayerCharacterAnimations(
  scene: Phaser.Scene,
  characters: PlayerCharacterMetadata[]
): void {
  for (const char of characters) {
    for (const anim of char.animations) {
      const sheetKey = getCharacterSpritesheetKey(char.characterId, anim.animationName);
      const frameRate = Math.max(1, Math.round(1000 / anim.frameDuration));

      for (const dir of anim.directionOrder) {
        const animKey = getPlayerAnimationKey(char.characterId, anim.animationName, dir);
        if (scene.anims.exists(animKey)) continue;

        const start = anim.startFrameByDirection[dir];
        const end = anim.endFrameByDirection[dir];

        scene.anims.create({
          key: animKey,
          frames: scene.anims.generateFrameNumbers(sheetKey, { start, end }),
          frameRate,
          repeat: anim.loop ? -1 : 0,
        });
      }
    }
  }
}

export function registerAllPlayerAnimationsFromManifest(scene: Phaser.Scene): void {
  const manifest = getPlayerManifest(scene);
  if (!manifest) return;
  registerPlayerCharacterAnimations(scene, manifest.characters);
}
