export type PlayerDirection =
  | 'south'
  | 'south-west'
  | 'west'
  | 'north-west'
  | 'north'
  | 'north-east'
  | 'east'
  | 'south-east';

export type PlayerAnimationName =
  | 'idle'
  | 'walk'
  | 'run'
  | 'attack'
  | 'hit'
  | 'death'
  | 'dodge'
  | 'special';

export interface PlayerAnimationMetadata {
  animationName: PlayerAnimationName;
  frameCount: number;
  frameDuration: number;
  loop: boolean;
  directionOrder: PlayerDirection[];
  spritesheetPath: string;
  framesPerDirection: number;
  directionsSupported: number;
  startFrameByDirection: Record<PlayerDirection, number>;
  endFrameByDirection: Record<PlayerDirection, number>;
  notes: string;
}

export interface PlayerCharacterMetadata {
  characterId: string;
  characterName: string;
  sourceReference: string;
  weapon: string;
  frameWidth: number;
  frameHeight: number;
  transparency: boolean;
  pixelArt: boolean;
  perspective: string;
  directionOrder: PlayerDirection[];
  anchor: { x: number; y: number };
  suggestedCollisionBounds: {
    x: number;
    y: number;
    width: number;
    height: number;
    note?: string;
  };
  animations: PlayerAnimationMetadata[];
}

export interface CharactersManifest {
  pack: string;
  version: string;
  engine: string;
  perspective: string;
  directionOrder: PlayerDirection[];
  characters: PlayerCharacterMetadata[];
}

export const PLAYER_MANIFEST_KEY = 'player_characters_manifest';

export function preloadPlayerManifest(scene: Phaser.Scene, basePath = 'assets/characters/player'): void {
  scene.load.json(PLAYER_MANIFEST_KEY, `${basePath}/characters_manifest.json`);
}

export function getPlayerManifest(scene: Phaser.Scene): CharactersManifest | undefined {
  return scene.cache.json.get(PLAYER_MANIFEST_KEY) as CharactersManifest | undefined;
}
