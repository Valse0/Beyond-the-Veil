import type Phaser from 'phaser';
import { getPlayerManifest, type PlayerCharacterMetadata } from './playerCharacterManifest';

export function getCharacterSpritesheetKey(characterId: string, animationName: string): string {
  return `player_${characterId}_${animationName}`;
}

export function preloadPlayerCharacterAssets(
  scene: Phaser.Scene,
  characters: PlayerCharacterMetadata[],
  assetRootPrefix = ''
): void {
  for (const char of characters) {
    for (const anim of char.animations) {
      const key = getCharacterSpritesheetKey(char.characterId, anim.animationName);
      if (scene.textures.exists(key)) continue;

      const url = assetRootPrefix
        ? `${assetRootPrefix.replace(/\/$/, '')}/${anim.spritesheetPath}`
        : anim.spritesheetPath;

      scene.load.spritesheet(key, url, {
        frameWidth: char.frameWidth,
        frameHeight: char.frameHeight,
      });
    }
  }
}

export function preloadPlayerCharactersFromManifest(scene: Phaser.Scene, assetRootPrefix = ''): void {
  const manifest = getPlayerManifest(scene);
  if (!manifest) return;
  preloadPlayerCharacterAssets(scene, manifest.characters, assetRootPrefix);
}
