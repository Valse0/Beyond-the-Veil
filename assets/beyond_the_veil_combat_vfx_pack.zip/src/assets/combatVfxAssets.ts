import type Phaser from 'phaser';

export interface WeaponMetadata {
  weaponId: string;
  name: string;
  category: 'melee' | 'magical' | 'ranged';
  frameWidth: number;
  frameHeight: number;
  states: string[];
  spritesheetPath: string;
  anchor: { x: number; y: number };
}

export interface VfxMetadata {
  vfxId: string;
  name: string;
  category: 'projectiles' | 'combat' | 'abilities';
  frameWidth: number;
  frameHeight: number;
  frameCount: number;
  frameDuration: number;
  flightFrames?: [number, number];
  impactFrames?: [number, number];
  spritesheetPath: string;
  anchor: { x: number; y: number };
}

export const WEAPONS_MANIFEST_KEY = 'weapons_manifest';
export const VFX_MANIFEST_KEY = 'vfx_manifest';

export function preloadWeaponsAndVfxManifests(scene: Phaser.Scene, basePath = 'assets'): void {
  scene.load.json(WEAPONS_MANIFEST_KEY, `${basePath}/weapons/weapons_manifest.json`);
  scene.load.json(VFX_MANIFEST_KEY, `${basePath}/vfx/vfx_manifest.json`);
}

export function preloadWeaponsAndVfxAssets(scene: Phaser.Scene, assetRootPrefix = ''): void {
  const wData = scene.cache.json.get(WEAPONS_MANIFEST_KEY) as { weapons?: WeaponMetadata[] } | undefined;
  const vData = scene.cache.json.get(VFX_MANIFEST_KEY) as { effects?: VfxMetadata[] } | undefined;
  const prefix = assetRootPrefix ? assetRootPrefix.replace(/\/$/, '') + '/' : '';

  for (const w of wData?.weapons ?? []) {
    const key = `weapon_${w.weaponId}`;
    if (!scene.textures.exists(key)) {
      scene.load.spritesheet(key, `${prefix}${w.spritesheetPath}`, {
        frameWidth: w.frameWidth,
        frameHeight: w.frameHeight,
      });
    }
  }

  for (const v of vData?.effects ?? []) {
    const key = `vfx_${v.vfxId}`;
    if (!scene.textures.exists(key)) {
      scene.load.spritesheet(key, `${prefix}${v.spritesheetPath}`, {
        frameWidth: v.frameWidth,
        frameHeight: v.frameHeight,
      });
    }
  }
}
