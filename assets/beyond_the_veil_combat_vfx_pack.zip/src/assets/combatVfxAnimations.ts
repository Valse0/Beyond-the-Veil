import type Phaser from 'phaser';
import { VFX_MANIFEST_KEY, type VfxMetadata } from './combatVfxAssets';

export function registerVfxAnimations(scene: Phaser.Scene): void {
  const vData = scene.cache.json.get(VFX_MANIFEST_KEY) as { effects?: VfxMetadata[] } | undefined;
  for (const v of vData?.effects ?? []) {
    const texKey = `vfx_${v.vfxId}`;
    const frameRate = Math.max(1, Math.round(1000 / v.frameDuration));

    if (v.category === 'projectiles' && v.flightFrames && v.impactFrames) {
      const flightKey = `${v.vfxId}_flight`;
      const impactKey = `${v.vfxId}_impact`;
      if (!scene.anims.exists(flightKey)) {
        scene.anims.create({
          key: flightKey,
          frames: scene.anims.generateFrameNumbers(texKey, {
            start: v.flightFrames[0],
            end: v.flightFrames[1],
          }),
          frameRate,
          repeat: -1,
        });
      }
      if (!scene.anims.exists(impactKey)) {
        scene.anims.create({
          key: impactKey,
          frames: scene.anims.generateFrameNumbers(texKey, {
            start: v.impactFrames[0],
            end: v.impactFrames[1],
          }),
          frameRate,
          repeat: 0,
        });
      }
    } else {
      if (!scene.anims.exists(v.vfxId)) {
        scene.anims.create({
          key: v.vfxId,
          frames: scene.anims.generateFrameNumbers(texKey, { start: 0, end: v.frameCount - 1 }),
          frameRate,
          repeat: 0,
        });
      }
    }
  }
}

/** Lightweight sprite pool for Survivors-like high-density combat VFX playback. */
export class VfxPool {
  private group: Phaser.GameObjects.Group;

  constructor(scene: Phaser.Scene, maxSize = 64) {
    this.group = scene.add.group({ maxSize });
  }

  playOnce(vfxId: string, x: number, y: number, rotation = 0, depth = 100): Phaser.GameObjects.Sprite | null {
    const sprite = this.group.get(x, y, `vfx_${vfxId}`) as Phaser.GameObjects.Sprite | null;
    if (!sprite) return null;
    sprite.setActive(true).setVisible(true).setPosition(x, y).setRotation(rotation).setDepth(depth);
    sprite.once('animationcomplete', () => {
      sprite.setActive(false).setVisible(false);
    });
    sprite.play(vfxId);
    return sprite;
  }
}
