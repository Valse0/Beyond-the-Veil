import type Phaser from 'phaser';
import { getEnemiesManifest, type EnemyMetadata } from './enemyManifest';

export function getEnemySpritesheetKey(enemyId: string, animationName: string): string {
  return `enemy_${enemyId}_${animationName}`;
}

export function preloadEnemyAssets(
  scene: Phaser.Scene,
  enemies: EnemyMetadata[],
  assetRootPrefix = ''
): void {
  for (const enemy of enemies) {
    for (const anim of enemy.animations) {
      const key = getEnemySpritesheetKey(enemy.enemyId, anim.animationName);
      if (scene.textures.exists(key)) continue;

      const url = assetRootPrefix
        ? `${assetRootPrefix.replace(/\/$/, '')}/${anim.spritesheetPath}`
        : anim.spritesheetPath;

      scene.load.spritesheet(key, url, {
        frameWidth: enemy.frameWidth,
        frameHeight: enemy.frameHeight,
      });
    }
  }
}

export function preloadEnemiesFromManifest(scene: Phaser.Scene, assetRootPrefix = ''): void {
  const manifest = getEnemiesManifest(scene);
  if (!manifest) return;
  preloadEnemyAssets(scene, manifest.enemies, assetRootPrefix);
}
