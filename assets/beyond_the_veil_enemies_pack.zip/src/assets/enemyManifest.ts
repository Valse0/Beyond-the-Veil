import type Phaser from 'phaser';

export type EnemyDirection =
  | 'south'
  | 'south-west'
  | 'west'
  | 'north-west'
  | 'north'
  | 'north-east'
  | 'east'
  | 'south-east';

export type EnemyAnimationName = 'idle' | 'walk' | 'run' | 'attack' | 'hit' | 'death';
export type EnemyRole = 'swarm' | 'chaser' | 'tank' | 'ranged' | 'flying' | 'special';

export interface EnemyAnimationMetadata {
  animationName: EnemyAnimationName;
  frameCount: number;
  frameDuration: number;
  loop: boolean;
  directionOrder: EnemyDirection[];
  spritesheetPath: string;
  startFrameByDirection: Record<EnemyDirection, number>;
  endFrameByDirection: Record<EnemyDirection, number>;
}

export interface EnemyMetadata {
  enemyId: string;
  enemyName: string;
  region: string;
  role: EnemyRole;
  locomotion: string;
  frameWidth: number;
  frameHeight: number;
  transparency: boolean;
  pixelArt: boolean;
  directionOrder: EnemyDirection[];
  anchor: { x: number; y: number };
  suggestedCollisionBounds: { x: number; y: number; width: number; height: number };
  animations: EnemyAnimationMetadata[];
}

export interface EnemiesManifest {
  pack: string;
  version: string;
  engine: string;
  perspective: string;
  totalEnemies: number;
  enemies: EnemyMetadata[];
}

export const ENEMIES_MANIFEST_KEY = 'enemies_manifest';

export function preloadEnemiesManifest(scene: Phaser.Scene, basePath = 'assets/characters/enemies'): void {
  scene.load.json(ENEMIES_MANIFEST_KEY, `${basePath}/enemies_manifest.json`);
}

export function getEnemiesManifest(scene: Phaser.Scene): EnemiesManifest | undefined {
  return scene.cache.json.get(ENEMIES_MANIFEST_KEY) as EnemiesManifest | undefined;
}
