import type Phaser from 'phaser';
import { getEnemySpritesheetKey } from './enemyAssets';
import {
  getEnemiesManifest,
  type EnemyAnimationName,
  type EnemyDirection,
  type EnemyMetadata,
} from './enemyManifest';

export function getEnemyAnimationKey(
  enemyId: string,
  animationName: EnemyAnimationName,
  direction: EnemyDirection
): string {
  return `enemy:${enemyId}:${animationName}:${direction}`;
}

export function registerEnemyAnimations(scene: Phaser.Scene, enemies: EnemyMetadata[]): void {
  for (const enemy of enemies) {
    for (const anim of enemy.animations) {
      const sheetKey = getEnemySpritesheetKey(enemy.enemyId, anim.animationName);
      const frameRate = Math.max(1, Math.round(1000 / anim.frameDuration));

      for (const dir of anim.directionOrder) {
        const animKey = getEnemyAnimationKey(enemy.enemyId, anim.animationName, dir);
        if (scene.anims.exists(animKey)) continue;

        scene.anims.create({
          key: animKey,
          frames: scene.anims.generateFrameNumbers(sheetKey, {
            start: anim.startFrameByDirection[dir],
            end: anim.endFrameByDirection[dir],
          }),
          frameRate,
          repeat: anim.loop ? -1 : 0,
        });
      }
    }
  }
}

export function registerAllEnemyAnimationsFromManifest(scene: Phaser.Scene): void {
  const manifest = getEnemiesManifest(scene);
  if (!manifest) return;
  registerEnemyAnimations(scene, manifest.enemies);
}
