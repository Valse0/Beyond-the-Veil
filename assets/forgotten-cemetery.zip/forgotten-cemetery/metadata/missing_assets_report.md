# Beyond the Veil — Asset Production 03: Forgotten Cemetery Eksik veya Birleştirilen Asset Raporu

Bu rapor, **Forgotten Cemetery** bölgesi için istenen kapsam ile teslim edilen **84 adet oyun varlığı** (28 adet `32x32` seamless zemin/geçiş karosu + 56 adet şeffaf PNG prop/mimari sprite) arasındaki eşlemeyi belgeler.

## 1. Kategori Bazlı Teslimat Özeti

| Kategori | Üretilen Sayı | Klasör | Notlar |
| :--- | :---: | :--- | :--- |
| A. Mezarlık Zemin Tileset'i | 28 | `terrain/ground/`, `stone-paths/`, `broken-floors/`, `transitions/` | `32x32` seamless karolar + N/S/E/W kenar, iç/dış köşe ve çapraz geçişler |
| B. Mezar Taşları | 8 | `gravestones/` | Düz, yuvarlak, gotik sivri, kırık, haç, kraliyet zincirli, ruhsal ve küme |
| C. Lahitler ve Mezar Yapıları | 8 | `sarcophagi/` | Küçük, kraliyet heykelli, **açık** (ayrı dosya), ışıklı, mühürlü, kemikli, kırık kapak, yarı çökmüş anıt mezar |
| D. Gotik Şapel ve Mimari | 8 | `chapels/`, `gothic-architecture/` | Küçük şapel, yıkık vitraylı cephe, çan kulesi, kemer, sütun çifti, demir çitli duvar, haçlı sunak, ana mezarlık kapısı |
| E. Yer Altı Mezarları ve Kriptler | 8 | `crypts/` | Kapalı/açık kript girişi, kırık kemer, zincirli duvar, nişli duvar, sütun, mühür platformu, ruh korumalı geçit |
| F. Kemikler ve Mezarlık Detayları | 8 | `bones-and-remains/` | Küçük/büyük kemik yığını, kafatası+el+kaburga, savaşçı kalıntıları, kırık tabut, zincir, fener, mum+cenaze kumaşı |
| G. Ruhsal ve Lanetli Nesneler | 8 | `cursed-objects/`, `spiritual-objects/` | Mor/turkuaz ruh kristali, kırık/aktif ruh mührü, lanetli tablet, enerji dikilitaşı, süzülen kristal+kitap, alevli lanetli anıt |
| H. Çevresel Detaylar | 8 | `environmental-details/` | Mermer moloz, vitray parçaları, şamdan, gargoyle, kitap+parşömen, kuru dikenli dal, solmuş çiçek, kırık demir kapı |
| **Toplam** | **84** | `atlases/`, `preview/`, `metadata/` | 2 Phaser 3 Atlas (`terrain` + `props`) + tam `manifest.json` |

## 2. Birleştirilen veya Ayrı Varyant Olarak Üretilmeyen Öğeler

Miktar uğruna kaliteyi düşürmemek ve gereksiz klon varyantlardan kaçınmak için aşağıdaki öğeler birleştirilmiş veya kapsam dışında bırakılmıştır:

1. **Ayrı Gölge ve Işık Efekt Katmanları**: Gölge katmanları Phaser 3'te dinamik elips/shader gölgesiyle kullanılmak üzere ayrı PNG olarak üretilmemiştir; ruhsal ışık efektleri ilgili özel nesneler (`cemetery_sarcophagus_glowing_01`, `cemetery_spirit_crystal_01`, `cemetery_cursed_monument_flame_01`) üzerinde piksel art olarak işlenmiştir.
2. **A. Zemin Tileset'i**: 16 zemin/taş/kırık zemin türü tam `32x32` seamless olarak üretildi; geçiş karoları (`transitions/`) temel koyu toprak ile gotik taş döşeme arasındaki 12 yönü (N/S/E/W, iç/dış köşe, çapraz) kapsayacak şekilde alfa şeffaflıklı olarak hazırlandı. Diğer zemin çiftleri arasındaki ek geçiş permütasyonları Phaser 3'te katmanlı tilemap blending ile çözülebilir.
3. **B. Mezar Taşları**: *İsimsiz*, *çatlamış*, *kadim sembollü* ve *devrilmiş* varyantlar `cemetery_gravestone_flat_01`, `cemetery_gravestone_broken_01`, `cemetery_gravestone_spirit_01` ve `cemetery_gravestone_cluster_01` içinde temsil edildi; 14 yerine 8 özgün siluet üretildi.
4. **C. Lahitler**: *Büyük anıt mezar* ve *küçük aile mezarı* `sarcophagi_mausoleum_ruined_01` olarak; *taş mezar platformu* ise `crypts/cemetery_crypt_seal_platform_01` ile modülerleştirildi.
5. **D. Gotik Şapel**: *Büyük terk edilmiş şapel* tek parça devasa bina yerine modüler parçalara (`cemetery_chapel_facade_ruined_01`, `chapels_bell_tower_ruined_01`, `cemetery_gothic_arch_01`, `cemetery_wall_iron_fence_01`) bölündü; ayrı *taş merdiven* ise `crypts/cemetery_crypt_entrance_open_01` içinde yer aldı.
6. **F–H. Detaylar ve Nadir Nesneler**: Benzer küçük objeler (ör. *kafatası + el + kaburga*, *kılıç + kalkan + zırh*, *mumlar + cenaze kumaşı + çiçek*, *kitap + parşömen*) okunabilirliği artırmak için uyumlu gruplar halinde birleştirildi.
