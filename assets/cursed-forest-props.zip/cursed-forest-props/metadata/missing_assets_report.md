# Beyond the Veil — Asset Production 02: Eksik veya Üretilemeyen / Birleştirilen Asset Raporu

Bu rapor, **Cursed Forest: Structures & Environmental Props** paketinde istenen ana liste ile teslim edilen **60 adet bağımsız şeffaf PNG sprite** arasındaki kapsam eşlemesini belgeler. Üretimde *"Az ama kaliteli, özgün ve tutarlı asset"* ilkesi esas alınmıştır.

## 1. Kategori Bazlı Özet

| Kategori | Üretilen Sprite Sayısı | Klasör | Durum |
| :--- | :---: | :--- | :--- |
| A. Kadim Sunaklar ve Ritüel Yapıları | 8 | `shrines/` | Tamamlandı (Temel + Özel Varyantlar) |
| B. Harabeler ve Taş Mimari | 8 | `ruins/` | Tamamlandı (Modüler Parçalar) |
| C. Köprüler ve Geçitler | 8 | `bridges/` | Tamamlandı (Yürünebilir/Engel Okunaklı) |
| D. Terk Edilmiş Kamplar | 8 | `abandoned-camps/` | Tamamlandı (Modüler Kamp Seti) |
| E. Mezarlar ve Unutulmuş Anıtlar | 8 | `graves/` | Tamamlandı |
| F. Kapılar ve Keşif Nesneleri | 8 | `gates-and-discoverables/` | Tamamlandı |
| G. Küçük Çevre Detayları | 12 | `environmental-details/` | Tamamlandı |
| **Toplam** | **60** | `atlases/` + `metadata/` + `preview/` | **Phaser 3 Atlas + JSON Manifest Hazır** |

## 2. Birleştirilen veya Ayrı Varyant Olarak Üretilmeyen Nesneler

Aşağıdaki kalemler gereksiz tekrar ve görsel gürültü yaratmamak için birleştirilmiş veya kapsam dışı bırakılmıştır:

1. **Gölge Katmanları (Ayrı Shadow Sprite'ları)**: Her nesne için ayrı gölge PNG'si üretilmemiştir; sprite'lar Phaser 3'te dinamik elips gölge veya shader gölgesi ile kullanılmak üzere şeffaf tabanlı olarak bırakılmıştır.
2. **A. Sunaklar — Birleştirilenler / Eksikler**:
   - *Üzerinde eski semboller bulunan taş levha* ve *Dört taş sütunlu ritüel alanı* → `forest_seal_platform_01` ve `forest_sacrificial_table_01` (köşelerinde 4 küçük ritüel taşı ile) içinde birleştirildi.
   - *Küçük ritüel taşları* ve *Kırılmış ritüel sütunları* → `ruins/forest_pillar_broken_01.png` ve `environmental-details/forest_detail_statue_fragments_01.png` ile modüler olarak karşılanmaktadır.
3. **B. Harabeler — Eksikler**:
   - *Yıkılmış duvar bölümü*, *Eski taş kapı çerçevesi*, *Köklerle kaplanmış taş yapı*, *Küçük taş platform*, *Yarım kalmış taş geçit*, *Eski uygarlığa ait duvar kalıntıları* → İlk paketteki harabe kemerleri ve bu paketteki 8 modüler parça (`forest_stone_arch_01`, `forest_stone_arch_ruined_01`, `forest_wall_mossy_01`, `forest_wall_corner_ruined_01`, `forest_stairs_broken_01` vb.) birleştirilerek oluşturulabilecek şekilde modüler bırakıldı; ayrı alt-varyantları üretilmedi.
4. **C. Köprüler — Eksikler**:
   - *Dar orman geçidi*, *Kırılmış korkuluklar* (ayrı parça olarak) → Korkuluklar `forest_pathway_stone_railing_01` üzerinde birleştirildi; dar orman geçidi Pack 01 zemin karolarıyla birleştirilmek üzere ayrı üretilmedi.
5. **D. Terk Edilmiş Kamplar — Birleştirilenler**:
   - *Kamp ateşi çevresinde taş halkası* → `forest_campfire_lit_01` ve `forest_campfire_extinguished_01` içine entegre edildi.
   - *Açık sandık* + *Kırılmış sandık*, *Ahşap varil* + *Kırılmış varil*, *Küçük ahşap masa* + *Sırt çantası* + *Kamp malzemeleri* + *Kırılmış el arabası* → Tutarlı sahne kompozisyonu için `forest_camp_chest_open_crate_01`, `forest_camp_barrel_cluster_01` ve `forest_camp_table_supplies_01` olarak gruplandı. (Ayrı kırık tekerlek ayrıca `environmental-details/forest_detail_cart_wheel_01.png` içinde tekil olarak mevcuttur.)
6. **E. Mezarlar — Birleştirilenler / Eksikler**:
   - *Yosunlu mezar taşı* ve *Kırılmış mezar taşı* → `forest_gravestone_broken_01` içinde birleştirildi.
   - *Kırılmış lahit* ve *Eski heykel parçası / Kırılmış heykel başı* → Tekil kırık lahit üretilmedi; heykel parçaları `forest_monument_spectral_01` ve `environmental-details/forest_detail_statue_fragments_01.png` olarak üretildi.
7. **F. Kapılar ve Keşif Nesneleri — Birleştirilenler / Eksikler**:
   - *Kırılmış kapı*, *Büyük hazine sandığı* (ayrı açık/kapalı), *Kırılmış büyülü mühür*, *Küçük enerji kaynağı*, *Ritüel objesi* → *Eski kitap* + *Parşömen* (`forest_lore_grimoire_scroll_01`) ve *Eski anahtar* + *Taş tablet* (`forest_relic_key_tablet_01`) tekil ikili prop olarak birleştirildi; kırık kapı ve ek sandık/enerji alt varyantları üretilmedi.
8. **G. Küçük Çevre Detayları — Eksikler**:
   - *Metal parçaları*, *Eski kumaş parçaları* (bayraktan ayrı olarak) ve *Küçük dekoratif ritüel objeleri* (kadeh dışında) ayrı dosya olarak üretilmedi.
