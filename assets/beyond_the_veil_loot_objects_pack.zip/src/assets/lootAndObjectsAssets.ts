import type Phaser from 'phaser';

export interface LootOrObjectEntry {
  id: string;
  name: string;
  region?: string;
  frameWidth: number;
  frameHeight: number;
  frameCount: number;
  frameDuration?: number;
  states?: string[];
  spritesheetPath: string;
  anchor: { x: number; y: number };
}

export interface LootAndObjectsManifest {
  loot: LootOrObjectEntry[];
  chests: LootOrObjectEntry[];
  destructibles: LootOrObjectEntry[];
  interactables: LootOrObjectEntry[];
  vfx: LootOrObjectEntry[];
}

export const LOOT_OBJECTS_MANIFEST_KEY = 'loot_and_objects_manifest';

export function preloadLootAndObjectsManifest(scene: Phaser.Scene, basePath = 'assets'): void {
  scene.load.json(LOOT_OBJECTS_MANIFEST_KEY, `${basePath}/loot_and_objects_manifest.json`);
}

export function preloadLootAndObjectsAssets(scene: Phaser.Scene, assetRootPrefix = ''): void {
  const manifest = scene.cache.json.get(LOOT_OBJECTS_MANIFEST_KEY) as LootAndObjectsManifest | undefined;
  if (!manifest) return;
  const prefix = assetRootPrefix ? assetRootPrefix.replace(/\/$/, '') + '/' : '';
  const all = [
    ...manifest.loot,
    ...manifest.chests,
    ...manifest.destructibles,
    ...manifest.interactables,
    ...manifest.vfx,
  ];
  for (const entry of all) {
    if (!scene.textures.exists(entry.id)) {
      scene.load.spritesheet(entry.id, `${prefix}${entry.spritesheetPath}`, {
        frameWidth: entry.frameWidth,
        frameHeight: entry.frameHeight,
      });
    }
  }
}
