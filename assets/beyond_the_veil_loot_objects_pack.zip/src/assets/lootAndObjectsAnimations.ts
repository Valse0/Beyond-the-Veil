import type Phaser from 'phaser';
import { LOOT_OBJECTS_MANIFEST_KEY, type LootAndObjectsManifest } from './lootAndObjectsAssets';

export function registerLootAndObjectsAnimations(scene: Phaser.Scene): void {
  const manifest = scene.cache.json.get(LOOT_OBJECTS_MANIFEST_KEY) as LootAndObjectsManifest | undefined;
  if (!manifest) return;

  for (const item of manifest.loot) {
    const key = `${item.id}_idle`;
    if (!scene.anims.exists(key)) {
      scene.anims.create({
        key,
        frames: scene.anims.generateFrameNumbers(item.id, { start: 0, end: item.frameCount - 1 }),
        frameRate: Math.max(1, Math.round(1000 / (item.frameDuration ?? 140))),
        repeat: -1,
      });
    }
  }

  for (const chest of manifest.chests) {
    const key = `${chest.id}_open`;
    if (!scene.anims.exists(key)) {
      scene.anims.create({
        key,
        frames: scene.anims.generateFrameNumbers(chest.id, { start: 0, end: chest.frameCount - 1 }),
        frameRate: 10,
        repeat: 0,
      });
    }
  }

  for (const dest of manifest.destructibles) {
    const key = `${dest.id}_break`;
    if (!scene.anims.exists(key)) {
      scene.anims.create({
        key,
        frames: scene.anims.generateFrameNumbers(dest.id, { start: 1, end: dest.frameCount - 1 }),
        frameRate: 12,
        repeat: 0,
      });
    }
  }

  for (const inter of manifest.interactables) {
    const key = `${inter.id}_activate`;
    if (!scene.anims.exists(key)) {
      scene.anims.create({
        key,
        frames: scene.anims.generateFrameNumbers(inter.id, { start: 0, end: inter.frameCount - 1 }),
        frameRate: 8,
        repeat: 0,
      });
    }
  }

  for (const fx of manifest.vfx) {
    if (!scene.anims.exists(fx.id)) {
      scene.anims.create({
        key: fx.id,
        frames: scene.anims.generateFrameNumbers(fx.id, { start: 0, end: fx.frameCount - 1 }),
        frameRate: Math.max(1, Math.round(1000 / (fx.frameDuration ?? 75))),
        repeat: 0,
      });
    }
  }
}
